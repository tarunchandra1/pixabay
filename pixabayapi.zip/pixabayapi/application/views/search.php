
<!DOCTYPE html>
<html lang="en">
<head>


<div class="container">
	<div class="row">
		<form >
		<div class="form-group">
			<label for="text">Search here Image & Video</label>
			<input type="text" placeholder="Search here Image & Video" id="search_id" class="form-control">
		</div>
		
		<div class="form-group">
		<label class="radio-inline"><input type="radio" name="optradio"  value="image" checked>Image</label>
		<label class="radio-inline"><input type="radio" name="optradio" value="video">Video</label>
		</div>
		<button type="button" onclick="myfunction()" class="btn btn-default">Search</button>
		</form>
	</div>
	
	
</div>


	<div class="row">
		<h2 style="    text-align: center;">Search Result</h2>
		<div id="search_result">

		</div>
		
		<!-- <div class="col-sm-3" >
		<img style="margin-top:20px; margin-left:30px" src="https://cdn.pixabay.com/photo/2015/01/20/11/09/black-605334_960_720.jpg" class="img-rounded" alt="Cinque Terre" width="304" height="236"> 
		</div>
		<div class="col-sm-3" >
		<img style="margin-top:20px; margin-left:30px" src="https://cdn.pixabay.com/photo/2015/01/20/11/09/black-605334_960_720.jpg" class="img-rounded" alt="Cinque Terre" width="304" height="236"> 
		</div>
		<div class="col-sm-3" >
		<img style="margin-top:20px; margin-left:30px" src="https://cdn.pixabay.com/photo/2015/01/20/11/09/black-605334_960_720.jpg" class="img-rounded" alt="Cinque Terre" width="304" height="236"> 
		</div>
		
		<div class="col-sm-3" >
		<img style="margin-top:20px; margin-left:30px" src="https://cdn.pixabay.com/photo/2015/01/20/11/09/black-605334_960_720.jpg" class="img-rounded" alt="Cinque Terre" width="304" height="236"> 
		</div> -->

	</div>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script>
function myfunction(){
var searchId = document.getElementById('search_id').value;

var radiovalue = $("input[name='optradio']:checked").val();
// var radio_image = document.getElementById('radio_image').value;
// var radio_video = document.getElementById('radio_video').value;
alert(radiovalue);

// alert(radio_image);
// alert(radio_video);
var API_KEY = '22585135-075d5c4f262069595fd721f59';
if(radiovalue == 'image'){
	var URL = "https://pixabay.com/api/?key="+API_KEY+"&q="+searchId+"&image_type=photo";
	$.getJSON(URL, function(data){
if (parseInt(data.totalHits) > 0)
    $.each(data.hits, function(i, hit){ 
		$('#search_result').append('<div class="col-sm-3"><img style="margin-top:20px; margin-left:30px;" src='+hit.largeImageURL+' "class="img-rounded" alt="Cinque Terre" width="304" height="236"></div>')
		// var img = "<img src='"+hit.largeImageURL+"' height=100 />";
		// document.getElementById('resutl'). = img ;
		//  console.log(hit.largeImageURL); 
		 });
	// console.log(data.hits.largeImageURL);
else
    console.log('No hits');
});
} else {
	var URL = "https://pixabay.com/api/videos/?key="+API_KEY+"&q="+searchId+" ";
	$.getJSON(URL, function(data){
if (parseInt(data.totalHits) > 0)
    $.each(data.hits, function(i, hit){ 
		$('#search_result').append('<div class="col-sm-3"><embed style="margin-top:20px; margin-left:30px;" src='+hit.videos.medium.url+'  alt="Cinque Terre" width="304" height="236"></div>')
		// var img = "<img src='"+hit.largeImageURL+"' height=100 />";
		// document.getElementById('resutl'). = img ;
		//  console.log(hit.videos.medium.url); 
		 });
	// console.log(data.hits.largeImageURL);
else
    console.log('No hits');
});
}


}

// function loee(){

// }
  </script>
</body>

</html>

